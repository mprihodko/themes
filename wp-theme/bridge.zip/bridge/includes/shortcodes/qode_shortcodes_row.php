<div id="qode_shortcode_form_wrapper">
<form id="qode_shortcode_form" name="qode_shortcode_form" method="post" action="">
  <div class="input">
    <label>Text Align</label>
    <select name="text_align" id="text_align">
			<option value="left">Left</option>
			<option value="center">Center</option>
			<option value="right">Right</option>
    </select>
  </div>
	<div class="input">
    <label>Css Animation</label>
    <select name="css_animation" id="css_animation">
			<option value="">No</option>
			<option value="element_from_right">Elements Shows From Left Side</option>
			<option value="element_from_top">Elements Shows From Right Side</option>
			<option value="element_from_top">Elements Shows From Top Side</option>
			<option value="element_from_bottom">Elements Shows From Bottom Side</option>
			<option value="element_from_fade">Elements Shows From Fade</option>
    </select>
  </div>
  <div class="input">
      <input type="submit" name="Insert" id="qode_insert_shortcode_button" value="Submit" />
  </div>
</form>
</div>