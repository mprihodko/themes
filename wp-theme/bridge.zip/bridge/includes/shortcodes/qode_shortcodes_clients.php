<div id="qode_shortcode_form_wrapper">
    <form id="qode_shortcode_form" name="qode_shortcode_form" method="post" action="">
        <div class="input">
            <label>Columns</label>
            <select name="columns" id="columns">
                <option value="two_columns">Two</option>
                <option value="three_columns">Three</option>
                <option value="four_columns">Four</option>
                <option value="five_columns">Five</option>
                <option value="six_columns">Six</option>
            </select>
        </div>
        <div class="input">
            <input type="submit" name="Insert" id="qode_insert_shortcode_button" value="Submit" />
        </div>
    </form>
</div>